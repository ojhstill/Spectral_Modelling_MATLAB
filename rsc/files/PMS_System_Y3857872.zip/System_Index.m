%% Setup
clear; clc;
close all;

% Spectrogram parameters.
N = 2^10;                       % Discrete Fourier values.
N_OVERLAP = N/2;
N_FFT = N;

%% User Variables

% Input variables.
recording_file = 'vocal.wav';   % File name with relative path.
pitch_transpose = -4;           % Pitch transposition in semitones.
res_balance = 0.1;              % Resonance balance percentage (0 to 1).

% Output variables.
PLAY_OUTPUT = false;      % Plays the resynthesised and transformed audio.
PLOT_COMPARASON = true;   % Plots the original & resynthesised spectrogram.
PLOT_PARTS = true;        % Plots the deterministic and stochastic parts.
LOG_SCALE = false;        % Switches from lin to log spectrogram y-axis.

%% System Design

% Read in audio file.
[recording, fs] = audioread(recording_file);

% Find number of channels and duration of the recording.
channels = min(size(recording));
duration = max(size(recording));

% Combine channels if file is stereo.
if channels == 2
  recording = (recording(:,1) + recording(:,2)) ./ 2;
end

% Ensure we're dealing with columnar recorded data.
if channels ~= size(recording,2)
  recording = recording';
end

% Prevent spectrogram errors.
if res_balance == 0
  res_balance = 0.00000001;
elseif res_balance == 1
  res_balance = 0.99999999;
end

% Identify sinusoidal and noise components.
[~, yh, ys] = spsmodel(recording, fs, blackman(1025), ...
  2^12, -100, 15, 1, pitch_transpose);

% Adjust resonance levels.
yh_bal = yh.*(res_balance);
ys_bal = ys.*(1 - res_balance);

y = (yh_bal + ys_bal).*2;

% Normalise.
y = y./max(abs(y));

%% System Output

% Play synthesised output.
if PLAY_OUTPUT
  soundsc(y, fs);
end

audiowrite('vocal_synth.wav', y, fs);

% Plot new resynthesised audio with original.
if PLOT_COMPARASON
  figure('Name','Spectral Comparason','Position',[200 200 1400 650]);

  subplot(1, 2, 1, 'align');
  if channels == 1
    spectrogram(recording, blackman(N), N_OVERLAP, N_FFT, fs, 'yaxis');
  end

  caxis([-160 0]);
  if LOG_SCALE
    set(gca,'YScale','log')
  end
  xlabel('Time (s)', 'FontSize', 14);
  ylabel('Frequency (kHz)', 'FontSize', 14);
  title('Original Audio', 'FontSize', 16);
  axOrg = gca;

  subplot(1, 2, 2, 'align');
  if channels == 1
    spectrogram(y, blackman(N), N_OVERLAP, N_FFT, fs, 'yaxis');
  end

  caxis([-160 0]);
  if LOG_SCALE
    set(gca,'YScale','log')
  end
  xlabel('Time (s)', 'FontSize', 14);
  ylabel('Frequency (kHz)', 'FontSize', 14);
  title('Resynthesised Audio', 'FontSize', 16);
  axRes = gca;
  

  linkaxes([axOrg axRes], 'xy');
end

% Plot resynthesised sinusoidal component with noise component.
if PLOT_PARTS
  figure('Name','Component Comparason','Position',[200 200 1400 650]);

  subplot(1, 2, 1, 'align');
  if channels == 1
    spectrogram(yh_bal, blackman(N), N_OVERLAP, N_FFT, fs, 'yaxis');
  end
  
  caxis([-160 0]);
  if LOG_SCALE
    set(gca,'YScale','log')
  end
  xlabel('Time (s)', 'FontSize', 14);
  ylabel('Frequency (kHz)', 'FontSize', 14);
  title('Deterministic Part', 'FontSize', 16);
  axDet = gca;

  subplot(1, 2, 2, 'align');
  if channels == 1
    spectrogram(ys_bal, blackman(N), N_OVERLAP, N_FFT, fs, 'yaxis');
  end
  
  caxis([-160 0]);
  if LOG_SCALE
    set(gca,'YScale','log')
  end
  xlabel('Time (s)', 'FontSize', 14);
  ylabel('Frequency (kHz)', 'FontSize', 14);
  title('Stochastic Part', 'FontSize', 16);
  axSto = gca;

  linkaxes([axDet axSto], 'xy');
end
